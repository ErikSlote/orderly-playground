import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Settings, ShoppingCart, Mic, Phone, Coffee, Pizza, UtensilsCrossed, Beef, Check } from "lucide-react";

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  addedByAI?: boolean;
}

const menuItems: MenuItem[] = [
  {
    id: 1,
    name: "Espresso",
    description: "A bold, concentrated shot of rich coffee with a smooth crema",
    price: 130,
    image: "https://images.unsplash.com/photo-1645445644664-8f44112f334c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3ByZXNzbyUyMGNvZmZlZSUyMGN1cHxlbnwxfHx8fDE3NzM4NzIyMDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Coffee",
  },
  {
    id: 2,
    name: "Vanilla Latte",
    description: "A smooth blend of espresso, steamed milk, and sweet vanilla syrup",
    price: 170,
    image: "https://images.unsplash.com/photo-1683122925249-8b15d807db4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2YW5pbGxhJTIwbGF0dGUlMjBjb2ZmZWV8ZW58MXx8fHwxNzczOTcyMTk5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Coffee",
  },
  {
    id: 3,
    name: "Cappuccino",
    description: "Classic Italian coffee with espresso, steamed milk, and foam",
    price: 150,
    image: "https://images.unsplash.com/photo-1708430651927-20e2e1f1e8f7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXBwdWNjaW5vJTIwY29mZmVlfGVufDF8fHx8MTc3Mzk1NzI0Nnww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Coffee",
  },
  {
    id: 4,
    name: "Margherita Pizza",
    description: "Fresh mozzarella, basil, and tomato sauce on crispy crust",
    price: 280,
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMG1hcmdoZXJpdGF8ZW58MXx8fHwxNzczOTY1MzA2fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Pizza",
  },
  {
    id: 5,
    name: "Pepperoni Pizza",
    description: "Classic pepperoni with mozzarella cheese and zesty tomato sauce",
    price: 320,
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXBwZXJvbmklMjBwaXp6YXxlbnwxfHx8fDE3NzM5NDQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Pizza",
  },
  {
    id: 6,
    name: "Pasta Carbonara",
    description: "Creamy pasta with pancetta, egg, and parmesan cheese",
    price: 250,
    image: "https://images.unsplash.com/photo-1588013273468-315fd88ea34c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXN0YSUyMGNhcmJvbmFyYXxlbnwxfHx8fDE3NzM5MDQxNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Pasta",
  },
];

const categories = [
  { name: "Coffee", icon: Coffee },
  { name: "Pizza", icon: Pizza },
  { name: "Pasta", icon: UtensilsCrossed },
  { name: "Fries", icon: Beef },
];

export default function App() {
  const [voiceExpanded, setVoiceExpanded] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("Coffee");
  const [cartCount, setCartCount] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");

  const filteredItems = menuItems.filter((item) => item.category === selectedCategory);

  const handleVoiceToggle = () => {
    if (!voiceExpanded) {
      setVoiceExpanded(true);
      setIsListening(true);
      // Simulate AI listening and transcribing
      setTimeout(() => {
        setTranscript("...and a vanilla latte with oat milk");
      }, 1500);
    } else {
      setIsListening(!isListening);
    }
  };

  const handleEndCall = () => {
    setVoiceExpanded(false);
    setIsListening(false);
    setTranscript("");
  };

  return (
    <div className="h-screen bg-gray-100 flex items-center justify-center">
      {/* Mobile Device Frame */}
      <div className="w-[390px] h-[844px] bg-[#1a2332] text-white overflow-hidden flex flex-col rounded-[3rem] shadow-2xl border-8 border-gray-800 relative">
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-7 bg-gray-800 rounded-b-3xl z-50" />
        
        {/* Simplified Header */}
        <header className="flex items-center justify-between px-5 py-4 pt-10 border-b border-gray-700/50">
          <div className="w-8" /> {/* Spacer */}
          <h1 className="text-base font-semibold">A1 Snacks</h1>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400">Table 1</span>
            <button className="p-1.5 hover:bg-gray-700/50 rounded-lg transition-colors">
              <Settings className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        </header>

        {/* Category Pills */}
        <div className="flex gap-2 px-5 py-3 overflow-x-auto scrollbar-hide border-b border-gray-700/30">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.name}
                onClick={() => setSelectedCategory(category.name)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full whitespace-nowrap transition-all text-sm ${
                  selectedCategory === category.name
                    ? "bg-[#f4845f] text-white"
                    : "bg-transparent text-gray-400 border border-gray-600"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {category.name}
              </button>
            );
          })}
        </div>

        {/* Menu Items - Scrollable */}
        <div className="flex-1 overflow-y-auto px-5 pt-4 pb-32">
          <div className="space-y-3">
            {filteredItems.map((item) => (
              <motion.div
                key={item.id}
                layout
                className="bg-[#243447] rounded-xl overflow-hidden relative"
              >
                {item.addedByAI && (
                  <div className="absolute top-2 right-2 z-10 bg-green-500 text-white text-[10px] px-2 py-0.5 rounded-full">
                    Added by AI
                  </div>
                )}
                <div className="flex gap-3 p-3">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white text-sm mb-0.5">{item.name}</h3>
                    <p className="text-xs text-gray-400 line-clamp-2 mb-2">
                      {item.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white text-sm">₱{item.price}</span>
                      <button
                        onClick={() => setCartCount(cartCount + 1)}
                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                          item.addedByAI
                            ? "bg-green-500"
                            : "bg-gray-600 hover:bg-gray-500"
                        }`}
                      >
                        {item.addedByAI ? (
                          <Check className="w-4 h-4 text-white" />
                        ) : (
                          <span className="text-white text-lg">+</span>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom Gradient Fade */}
        <div className="absolute bottom-0 left-0 right-0 h-36 bg-gradient-to-t from-[#1a2332] via-[#1a2332]/95 to-transparent pointer-events-none" />

        {/* Floating Voice Island */}
        <div className="absolute bottom-5 left-5 right-5 flex items-end gap-2.5 z-20">
          <AnimatePresence mode="wait">
            {!voiceExpanded ? (
              // Collapsed State
              <motion.button
                key="collapsed"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                onClick={handleVoiceToggle}
                className="flex-1 h-12 bg-[#2a3c52] rounded-xl px-3 flex items-center gap-2.5 hover:bg-[#324456] transition-colors"
              >
                <div className="w-8 h-8 bg-[#f4845f] rounded-full flex items-center justify-center flex-shrink-0">
                  <Mic className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="font-semibold text-white text-xs leading-tight">Voice AI ready</div>
                  <div className="text-[10px] text-gray-400 leading-tight">Tap to speak</div>
                </div>
                <div className="flex gap-0.5 items-center">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className="w-0.5 bg-gray-500 rounded-full"
                      style={{ height: `${8 + i * 2}px` }}
                    />
                  ))}
                </div>
              </motion.button>
            ) : (
              // Expanded State
              <motion.div
                key="expanded"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="flex-1 h-12 bg-[#2a3c52] rounded-xl px-3 flex items-center gap-3"
              >
                {/* Live Waveform */}
                <div className="flex gap-0.5 items-center h-6">
                  {[...Array(12)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-0.5 bg-[#f4845f] rounded-full"
                      animate={
                        isListening
                          ? {
                              height: [8, 20, 12, 18, 8],
                            }
                          : { height: 8 }
                      }
                      transition={{
                        duration: 0.8,
                        repeat: Infinity,
                        delay: i * 0.05,
                      }}
                    />
                  ))}
                </div>

                {/* Real-time Transcript */}
                <div className="flex-1 min-w-0">
                  {transcript ? (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-[10px] text-gray-300 truncate"
                    >
                      {transcript}
                    </motion.div>
                  ) : (
                    <div className="text-[10px] text-gray-400">Listening...</div>
                  )}
                </div>

                {/* Controls */}
                <div className="flex gap-1.5 items-center flex-shrink-0">
                  <button
                    onClick={handleVoiceToggle}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                      isListening ? "bg-[#f4845f]" : "bg-gray-600"
                    }`}
                  >
                    <Mic className="w-3.5 h-3.5 text-white" />
                  </button>
                  <button
                    onClick={handleEndCall}
                    className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-white rotate-[135deg]" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Cart Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="w-12 h-12 bg-[#f4845f] rounded-xl flex items-center justify-center relative hover:bg-[#e67656] transition-colors flex-shrink-0"
          >
            <ShoppingCart className="w-5 h-5 text-white" />
            {cartCount > 0 && (
              <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-bold">
                {cartCount}
              </div>
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}